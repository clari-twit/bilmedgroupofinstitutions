import Login from 'views/authentication/Login';

export { Login };
