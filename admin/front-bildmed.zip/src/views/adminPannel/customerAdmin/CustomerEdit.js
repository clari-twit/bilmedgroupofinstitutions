import React from 'react'

export function CustomerEdit() {
  return (
    <div>CourceEdit</div>
  )
}



export default CustomerEdit;