export const setLocalStorageItem = (key, value) => {
  return localStorage.setItem(key, value);
};

export const getLocalStorageItem = (key) => {
  return localStorage.getItem(key);
};
