export const REQUIRED_PASSWORD = 'Password is required!';
export const REQUIRED_USERNAME = 'User name is required!';
