export const selectedTableRow = (data) => {
  return {
    type: 'SELCTED_ROW_DATA',
    payload: data
  }
}
