export const setSidebarOpen = (data) => {
  return {
    type: 'USER_SIDEBAR_OPEN',
    payload: data
  }
}
