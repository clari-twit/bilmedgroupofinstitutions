import Layout from 'layout/Layout';
import NotFoundPage from 'layout/NotFoundPage';

export { Layout, NotFoundPage };
