import "dotenv/config";
import express from "express";
import cors from "cors";
import cookieParser from "cookie-parser";
import bodyParser from "body-parser";

import CustomerController from "../controllers/CustomerController.js";
import auth from "../middleware/auth.js";

const route = express.Router();

route.use(
  cors({
    origin: `${process.env.FRONT_URL}`,
    credentials: true,
    optionsSuccessStatus: 200,
    methods: "GET,HEAD,PUT,PATCH,POST,DELETE",
  })
);
route.use(
  bodyParser.json({
    extended: true,
  })
);
route.use(
  bodyParser.urlencoded({
    extended: true,
  })
);
route.use(cookieParser());

// mobile api routes Start

route.post("/customerauth", CustomerController.login);

route.post("/forgotpassword", CustomerController.forgetPassword);

// mobile api routes End

// Web api routes Start

route.get("/", auth, CustomerController.getCustomer);

route.get("/details", auth, CustomerController.editCustomer);

route.post("/add", auth, CustomerController.insertCustomer);

route.put("/update", auth, CustomerController.updateCustomer);

route.delete("/multidelete", auth, CustomerController.deleteMultipleCustomers);

route.get("/country", auth, CustomerController.getCountry);

route.get("/state", auth, CustomerController.getStateByCountryId);

route.get("/autocomplete", auth, CustomerController.searchByCourseName);

// Web api routes Start

export default route;
